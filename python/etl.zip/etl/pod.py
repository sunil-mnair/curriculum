import pandas as pd
from etl import extract, transform, predict, load
from sklearn.linear_model import LogisticRegression

def run_etl_pipeline(input_file_path, output_file_path, model_path):
    print(f"\n--- Running ETL Pipeline for {input_file_path} ---")

    # 1. Extract
    new_data = extract(input_file_path)
    if new_data is None:
        print("ETL pipeline terminated due to extraction error.")
        return

    # Keep a copy of the original data to attach predictions later
    original_new_data = new_data.copy()

    # 2. Transform
    transformed_data = transform(new_data)
    if transformed_data is None:
        print("ETL pipeline terminated due to transformation error.")
        return

    # 3. Predict
    predictions, prediction_proba = predict(transformed_data, model_path)
    if predictions is None:
        print("ETL pipeline terminated due to prediction error.")
        return

    # Add predictions back to the original new_data_df for output
    original_new_data['Predicted_Loan_Status'] = predictions
    original_new_data['Prediction_Probability_Charged_Off'] = prediction_proba

    # 4. Load
    load(original_new_data, output_file_path)
    print(f"\n--- ETL Pipeline completed. Results saved to {output_file_path} ---")


if __name__ == "__main__":
    # Define file paths
    input_csv_file = 'test_data.csv'
    output_csv_file = 'new_data_predictions.csv'
    model_pkl_file = 'logistic_regression_model.pkl'

    # Run the pipeline
    run_etl_pipeline(input_csv_file, output_csv_file, model_pkl_file)

    output_df = pd.read_csv(output_csv_file)