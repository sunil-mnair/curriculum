from flask import Flask, request, render_template, jsonify
import os
import pandas as pd
import pickle
import traceback

# Creating an Object of the Flask App
app = Flask(__name__)

project_dir = os.path.dirname(os.path.abspath(__file__))

# Load Model Pipeline once when the server starts
# Read from the static folder as per your local structure
model_path = os.path.join(project_dir, 'static', 'logistic_regression_sentiment_model.pkl')
try:
    with open(model_path, 'rb') as file:
        loaded_pipeline = pickle.load(file)
except FileNotFoundError:
    # Fallback just in case
    with open('logistic_regression_sentiment_model.pkl', 'rb') as file:
        loaded_pipeline = pickle.load(file)

# Dedicated preprocessing function for incoming web data
def preprocess_data_for_flask(df, selected_features, scaler):
    df_processed = df.copy()

    if 'Response Time (hrs)' in df_processed.columns:
        df_processed['Response Time (hrs)'] = pd.to_numeric(df_processed['Response Time (hrs)'], errors='coerce')
    for col in ['Response Time (hrs)', 'Rating (1-5)']:
        if col in df_processed.columns and df_processed[col].isnull().any():
            df_processed[col].fillna(df_processed[col].median(), inplace=True)

    categorical_cols_impute = ['Source Channel', 'Customer Segment', 'Agent ID', 'Theme Category']
    for col in categorical_cols_impute:
        if col in df_processed.columns and df_processed[col].isnull().any():
            df_processed[col].fillna(df_processed[col].mode()[0], inplace=True)


    columns_to_standardize = ['Source Channel', 'Customer Segment', 'Service Type', 'Department', 'Location', 'Language', 'Device Type', 'Theme Category']
    for col in columns_to_standardize:
        if col in df_processed.columns and df_processed[col].dtype == 'object':
            df_processed[col] = df_processed[col].str.lower().str.strip()

    all_mappings = {
        'Source Channel': {'e-mail': 'email', 'in person': 'in-person', 'call center': 'call centre', 'social_media': 'social media', 'website chat': 'web chat', 'app': 'mobile app'},
        'Customer Segment': {'gov': 'government', 'first-time': 'new', 'new customer': 'new', 'premium customer': 'premium', 'corporate': 'business', 'b2b': 'business', 'public sector': 'government'},
        'Service Type': {'tech support': 'technical support', 'tech': 'technical support', 'it support': 'technical support', 'complaint': 'complaints', 'product': 'product inquiry', 'products': 'product inquiry', 'product info': 'product inquiry', 'accounts': 'account services', 'account': 'account services', 'account mgmt': 'account services', 'problem': 'issue', 'info': 'general inquiry', 'general': 'general inquiry', 'invoice': 'billing'},
        'Department': {'cs': 'customer service', 'cust service': 'customer service', 'operation': 'operations', 'ops': 'operations', 'tech dept': 'technical', 'sales team': 'sales'},
        'Location': {'abudhabi': 'abu dhabi', 'abu-dhabi': 'abu dhabi', 'fuj': 'fujairah', 'fujaira': 'fujairah', 'r.a.k.': 'ras al khaimah', 'rak': 'ras al khaimah', 'sharjah center': 'sharjah', 'shj': 'sharjah', 'ajm': 'ajman', 'ajman branch': 'ajman', 'umm al-quwain': 'umm al quwain', 'uaq': 'umm al quwain', 'umq': 'umm al quwain', 'dubai main': 'dubai'},
        'Language': {'ar': 'arabic', 'en': 'english'}
    }
    for col, mapping_dict in all_mappings.items():
        if col in df_processed.columns:
            df_processed[col] = df_processed[col].replace(mapping_dict)

    df_encoded = df_processed.drop(columns=['Feedback ID', 'Customer ID', 'Submission Date', 'Feedback Text', 'Sentiment Label'], errors='ignore')
    categorical_cols = df_encoded.select_dtypes(include='object').columns
    df_encoded = pd.get_dummies(df_encoded, columns=categorical_cols, drop_first=True)

    missing_cols = set(selected_features) - set(df_encoded.columns)
    for c in missing_cols:
        df_encoded[c] = False

    df_encoded = df_encoded[selected_features]

    for col in selected_features:
        df_encoded[col] = pd.to_numeric(df_encoded[col], errors='coerce').fillna(0).astype(float)

    df_encoded[selected_features] = scaler.transform(df_encoded[selected_features])
    return df_encoded

@app.route('/', methods=['GET', 'POST'])
def index():
    table_html = None
    error_msg = None

    if request.method == 'POST':
        try:
            df = None

            if 'file' in request.files and request.files['file'].filename != '':
                file = request.files['file']
                if file.filename.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    df = pd.read_excel(file)

            elif 'url' in request.form and request.form['url'] != '':
                url = request.form['url']
                if url.endswith('.csv'):
                    df = pd.read_csv(url)
                else:
                    try:
                        df = pd.read_excel(url, sheet_name='Test Data - Feedback')
                    except:
                        df = pd.read_excel(url)

            if df is not None:
                df_display = df.copy()

                X_test = preprocess_data_for_flask(df, loaded_pipeline['selected_features'], loaded_pipeline['scaler'])
                predictions = loaded_pipeline['model'].predict(X_test)

                df_display.insert(0, 'Predicted Sentiment', predictions)
                table_html = df_display.to_html(classes='table table-striped table-hover m-0', index=False)
                table_html = table_html.replace('<th>Predicted Sentiment</th>', '<th class="bg-success text-white">Predicted Sentiment</th>')
            else:
                error_msg = "Please upload a file or provide a valid URL."

        except Exception as e:
            error_msg = f"An error occurred processing the data: {str(e)}"

    return render_template('index.html', table=table_html, error_msg=error_msg)