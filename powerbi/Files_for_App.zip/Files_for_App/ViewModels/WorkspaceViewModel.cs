namespace PowerBiEmbed.ViewModels
{
	// For a workspace, represents all reports and datasets, and the embed token
	public class WorkspaceViewModel
	{
		public string ReportsJson;
		public string DatasetsJson;
		public string EmbedToken;
	}
}