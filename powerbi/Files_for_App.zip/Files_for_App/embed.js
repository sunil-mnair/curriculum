var reports = window.reports;
var datasets = window.datasets;
var embedToken = window.embedToken;
var models = window['powerbi-client'].models;

// Get a reference to the embed container
var embedContainer = document.getElementById('embed-container');


// Generate nav links for reports and datasets
$(function () {
    var reportsList = $("#reports-list");
    var datasetsList = $("#datasets-list");

    if (reports.length == 0) {
        reportsList.append($("<li>").text("[None]"));
    }
    else {
        reports.forEach((report) => {
            var li = $("<li>");
            li.append($("<a>", {
                "href": "javascript:void(0);"
            }).text(report.Name).click(() => { embedReport(report) }));
            reportsList.append(li);
        });
    }

    if (datasets.length == 0) {
        datasetsList.append($("<li>").text("[None]"));
    }
    else {
        datasets.forEach((dataset) => {
            var li = $("<li>");
            li.append($("<a>", {
                "href": "javascript:void(0);"
            }).text(dataset.Name).click(() => { embedQnaDataset(dataset) }));
            datasetsList.append(li);
        });
    }
});

// Embed a report
var embedReport = (report, editMode) => {

    // Create the report embed config object
    var config = {
        type: 'report',
        id: report.Id,
        embedUrl: report.EmbedUrl,
        accessToken: embedToken,
        tokenType: models.TokenType.Embed,
        permissions: models.Permissions.All,
        viewMode: editMode ? models.ViewMode.Edit : models.ViewMode.View,
        settings: {
            panes: {
                filters: { visible: true },
                pageNavigation: { visible: true }
            }
        }
    };

    

    console.log(report.EmbedUrl);
    
    powerbi.reset(embedContainer);

    // Embed the report
    var embeddedReport = powerbi.embed(embedContainer, config);

    console.log(report.EmbedUrl);
}

// Embed the Q&A experience
var embedQnaDataset = (dataset) => {

    // Create the Q&A embed config object
    var config = {
        type: 'qna',
        tokenType: models.TokenType.Embed,
        accessToken: embedToken,
        embedUrl: dataset.EmbedUrl,
        datasetIds: [dataset.Id],
        viewMode: models.QnaMode.Interactive
    };

    // Get a reference to the embed container
    // var embedContainer = document.getElementById('embed-container');

    // Embed the Q&A experience
    var embeddedObject = powerbi.embed(embedContainer, config);
}

function embedVisuals(){

    console.log("Embed Visual CLicked");
    // Create the report embed config object
    let visualConfig = {
        type: 'visual',
        id: 'f5a967ad-0bd9-4947-9c75-7e279c47e558',
        embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=f5a967ad-0bd9-4947-9c75-7e279c47e558&groupId=f05b632b-d5b2-4130-be57-32b069fc1bbf&w=2&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLVVBRS1OT1JUSC1BLVBSSU1BUlktcmVkaXJlY3QuYW5hbHlzaXMud2luZG93cy5uZXQiLCJlbWJlZEZlYXR1cmVzIjp7Im1vZGVybkVtYmVkIjp0cnVlLCJ1c2FnZU1ldHJpY3NWTmV4dCI6dHJ1ZX19',
        accessToken: embedToken,
        tokenType: models.TokenType.Embed,
        pageName:'ReportSectiondecccb8482fa6cf4f797',
        visualName:"875b419d4b78e8d8a80b"
    };

    powerbi.reset(embedContainer);
    
    // Embed the Visual
    var embeddedVisual = powerbi.embed(embedContainer, visualConfig);

    embeddedVisual.updateFilters(FiltersOperations.Add, filters, FiltersLevel.Report);
}


// Filter reports by product demographic
$(document).ready(function () {
	$('#demographic').change(function () {
		const report = powerbi.embeds[0];
		const demographic = this.value;

		const removeFilters = (demographic == "*");
		const basicFilter = {
			"$schema": "http://powerbi.com/product/schema#basic",
			"target": {
				"table": "Product",
				"column": "Demographic"
			},
			"operator": removeFilters ? "All" : "In",
			"values": removeFilters ? [] : [demographic]
		}
		
		// Update filters
		report.updateFilters(models.FiltersOperations.Replace, [basicFilter])
			.catch(error => { console.log(error); });
	});

    $('#theme').change(function () {
		const report = powerbi.embeds[0];
		const theme = this.value;

		if(theme == 'fire'){
            const theme = {
                "name": "Sample Theme",
                "dataColors": ["#990011", "#cc1144", "#ee7799", "#eebbcc", "#cc4477", "#cc5555", "#882222", "#A30E33"],
                "background": "#FFFFFF",
                "foreground": "#007799",
                "tableAccent": "#990011"
            };
            
            // Update the theme by passing in the custom theme.
            // Some theme properties might not be applied if your report has custom colors set.        
            report.applyTheme({ themeJson: theme });
        }
        else{
            report.reload();
        }

	});



});


function fullScreen(){
    const report = powerbi.embeds[0];
    report.fullscreen()
};


    
