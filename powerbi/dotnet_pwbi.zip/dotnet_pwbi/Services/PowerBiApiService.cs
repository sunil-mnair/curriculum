using System;  // Provides basic functionality like working with dates, times, and exceptions
using System.Collections.Generic;  // Provides collections like List<T>
using System.Threading.Tasks;  // Enables asynchronous programming (async/await)
using Microsoft.Extensions.Configuration;  // Helps in accessing configuration settings (e.g., from appsettings.json)
using Microsoft.Identity.Web;  // Used for acquiring access tokens
using Microsoft.PowerBI.Api;  // Provides access to Power BI API
using Microsoft.PowerBI.Api.Models;  // Contains models used with the Power BI API
using Microsoft.Rest;  // Provides REST-related features like TokenCredentials
using Newtonsoft.Json;  // Used to convert objects to and from JSON format
using PowerBiEmbed.Models;  // References custom models defined in the project (e.g., EmbeddedReport, EmbeddedDataset)
using PowerBiEmbed.ViewModels;  // References custom view models for the project

namespace PowerBiEmbed.Services  // Declares the namespace for the service
{
    // This service class provides methods to interact with the Power BI API
    public class PowerBiApiService
    {
        // Private fields to store the configuration and token acquisition service
        private IConfiguration _configuration;
        private ITokenAcquisition _tokenAcquisition;
        private Uri _powerBiServiceApiRootUrl;  // Stores the base URL for Power BI API
        private Guid _workspaceId;  // Stores the unique identifier (ID) for the Power BI workspace
        
        // This constant defines the default scope required for Power BI API access
        public const string PowerBiDefaultScope = "https://analysis.windows.net/powerbi/api/.default";

        // Constructor that initializes the service with configuration and token acquisition services
        public PowerBiApiService(IConfiguration configuration, ITokenAcquisition tokenAcquisition)
        {
            // Retrieves and stores Power BI API settings from the configuration file (e.g., appsettings.json)
            _configuration = configuration;
            _powerBiServiceApiRootUrl = new Uri(configuration["PowerBi:ServiceRootUrl"]);
            _workspaceId = new Guid(configuration["PowerBi:WorkspaceId"]);
            _tokenAcquisition = tokenAcquisition;  // Injected service for getting access tokens
        }

        // This method retrieves an access token using the ITokenAcquisition service
        public string GetAccessToken()
        {
            // Acquires the token for the specified Power BI API scope
            return _tokenAcquisition.GetAccessTokenForAppAsync(PowerBiDefaultScope).Result;
        }

        // This method returns a PowerBIClient object, which is used to call the Power BI API
        public PowerBIClient GetPowerBiClient()
        {
            // Acquires token credentials for authentication
            var tokenCredentials = new TokenCredentials(GetAccessToken(), "Bearer");
            
            // Returns a new Power BI client instance using the base API URL and the token credentials
            return new PowerBIClient(_powerBiServiceApiRootUrl, tokenCredentials);
        }

        // This method retrieves Power BI report and dataset embedding data for a specific workspace
        public async Task<WorkspaceViewModel> GetReportsEmbeddingData()
        {
            // Connect to the Power BI API using the client
            var client = GetPowerBiClient();
            
            // Get the list of reports in the specified Power BI workspace
            var reports = (await client.Reports.GetReportsInGroupAsync(_workspaceId)).Value;
            
            // Prepare lists to store report details and token requests for embedding
            var reportList = new List<EmbeddedReport>();
            var reportTokenRequests = new List<GenerateTokenRequestV2Report>();
            
            // Iterate over each report to extract relevant data
            foreach (var report in reports)
            {
                // Add report details to the list (ID, Name, and Embed URL)
                reportList.Add(new EmbeddedReport
                {
                    Id = report.Id.ToString(),
                    Name = report.Name,
                    EmbedUrl = report.EmbedUrl
                });
                
                // Add report to the token request list (no edit permission)
                reportTokenRequests.Add(new GenerateTokenRequestV2Report(report.Id, allowEdit: false));
            }
            
            // Get the list of datasets in the specified Power BI workspace
            var datasets = (await client.Datasets.GetDatasetsInGroupAsync(_workspaceId)).Value;
            
            // Prepare lists to store dataset details and token requests for embedding
            var datasetList = new List<EmbeddedDataset>();
            var datasetTokenRequests = new List<GenerateTokenRequestV2Dataset>();
            
            // Iterate over each dataset to extract relevant data
            foreach (var dataset in datasets)
            {
                // Add dataset details to the list (ID, Name, and Embed URL)
                datasetList.Add(new EmbeddedDataset
                {
                    Id = dataset.Id.ToString(),
                    Name = dataset.Name,
                    EmbedUrl = dataset.QnaEmbedURL
                });
                
                // Add dataset to the token request list
                datasetTokenRequests.Add(new GenerateTokenRequestV2Dataset(dataset.Id));
            }
            
            // Create a request to generate an embed token for the workspace
            var workspaceRequests = new GenerateTokenRequestV2TargetWorkspace[] {
                new GenerateTokenRequestV2TargetWorkspace(_workspaceId)
            };
            
            // Bundle all token requests (for reports, datasets, and the workspace)
            var tokenRequest = new GenerateTokenRequestV2(
                reports: reportTokenRequests,
                datasets: datasetTokenRequests,
                targetWorkspaces: workspaceRequests
            );
            
            // Generate the embed token asynchronously using the Power BI API
            string embedToken = (await client.EmbedToken.GenerateTokenAsync(tokenRequest)).Token;
            
            // Return a view model containing the report and dataset embedding data along with the generated embed token
            return new WorkspaceViewModel
            {
                ReportsJson = JsonConvert.SerializeObject(reportList),  // Serialize reports as JSON
                DatasetsJson = JsonConvert.SerializeObject(datasetList),  // Serialize datasets as JSON
                EmbedToken = embedToken  // Embed token for the workspace
            };
        }
    }
}
