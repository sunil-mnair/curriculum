namespace PowerBiEmbed.ViewModels  // Declares the namespace, organizing view models related to Power BI embedding
{
    // This class represents the view model for a Power BI workspace, including all reports, datasets, and the embed token.
    public class WorkspaceViewModel
    {
        // A JSON string that contains all the Power BI reports in the workspace
        public string ReportsJson;

        // A JSON string that contains all the Power BI datasets in the workspace
        public string DatasetsJson;

        // The embed token, which is required to securely embed reports and datasets
        public string EmbedToken;
    }
}
