﻿using System.Diagnostics;  // Used for accessing diagnostic and tracing functionality
using Microsoft.AspNetCore.Mvc;  // Provides access to ASP.NET Core MVC features
using dotnet_pwbi.Models;  // References models defined in the project
using PowerBiEmbed.Services;  // References services for Power BI embedding

namespace dotnet_pwbi.Controllers  // Declares the namespace for the HomeController class
{
    // The HomeController inherits from the base 'Controller' class provided by ASP.NET Core MVC
    public class HomeController : Controller
    {
        // Private field to store a service object that handles Power BI API interactions
        private PowerBiApiService _powerBiApiService;

        // Constructor to initialize the HomeController with a PowerBiApiService instance
        // Dependency Injection is used to provide the service (injected automatically by ASP.NET Core)
        public HomeController(PowerBiApiService powerBiServiceApi)
        {
            _powerBiApiService = powerBiServiceApi;  // Assigns the injected service to the private field
        }

        // This is an asynchronous method that handles the 'Index' action.
        // It fetches Power BI reports embedding data using the service and passes it to the view.
        public async Task<IActionResult> Index()
        {
            // Fetches the embedding data from the PowerBiApiService asynchronously
            var viewModel = await _powerBiApiService.GetReportsEmbeddingData();

            // Returns the view with the retrieved data (viewModel)
            return View(viewModel);
        }

        // This method handles the 'Privacy' action, which simply returns the 'Privacy' view
        public IActionResult Privacy()
        {
            return View();
        }

        // The 'Error' method returns the 'Error' view along with a model that contains diagnostic information
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]  // Ensures that error pages are not cached
        public IActionResult Error()
        {
            // Creates a new ErrorViewModel object, providing a request ID for tracing if available
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
