// The 'WebApplication.CreateBuilder' method sets up the app's configuration and services (Dependency Injection container).
var builder = WebApplication.CreateBuilder(args);

// This line creates an instance of the 'Startup' class from the 'SalesReporting' namespace and passes the configuration to it.
var startup = new SalesReporting.Startup(builder.Configuration);

// Calls 'ConfigureServices' from the 'Startup' class to register services in the Dependency Injection (DI) container.
startup.ConfigureServices(builder.Services);

// Adds controllers with views to the service container (for MVC functionality).
builder.Services.AddControllersWithViews();

// Builds the WebApplication object, which is the actual app that runs.
var app = builder.Build();

// Configures the middleware (pipeline components) used in the app.
if (!app.Environment.IsDevelopment()) // Checks if the app is running in a production environment.
{
    // In a non-development environment, use a custom error handler for errors (redirects to /Home/Error).
    app.UseExceptionHandler("/Home/Error");
    
    // Enforces HTTP Strict Transport Security (HSTS) with a default 30-day value (used to improve security in production).
    app.UseHsts();
}

// Middleware to redirect HTTP requests to HTTPS.
app.UseHttpsRedirection();

// Middleware to serve static files (like CSS, JavaScript, images, etc.) from wwwroot.
app.UseStaticFiles();

// Adds middleware to define how requests are routed (matching requests to endpoints like controllers).
app.UseRouting();

// Middleware to ensure the user is authorized for certain routes/actions (if authorization is configured).
app.UseAuthorization();

// Maps incoming requests to controllers based on the route pattern. The default route is Home/Index.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"); // Sets Home as the default controller and Index as the default action.

// Runs the application (starts listening for incoming requests).
app.Run();
