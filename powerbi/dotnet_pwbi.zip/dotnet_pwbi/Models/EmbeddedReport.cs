namespace PowerBiEmbed.Models  // Declares the namespace for organizing code related to Power BI embedding models
{
    // This class represents a Power BI report, containing essential details such as the report's ID, name, and embed URL.
    public class EmbeddedReport
    {
        // 'Id' holds the unique identifier for the Power BI report.
        public string Id;

        // 'Name' contains the name of the Power BI report.
        public string Name;

        // 'EmbedUrl' stores the URL used to embed the report, enabling it to be displayed in external applications.
        public string EmbedUrl;
    }
}
