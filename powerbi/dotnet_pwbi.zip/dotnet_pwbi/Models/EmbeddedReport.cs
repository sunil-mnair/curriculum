namespace PowerBiEmbed.Models
{
	// Represents a Power BI report
	public class EmbeddedReport
	{
		public string Id;
		public string Name;
		public string EmbedUrl;
	}
}