namespace PowerBiEmbed.Models  // Declares the namespace for organizing code related to Power BI embedding
{
    // This class represents a Power BI dataset, containing details such as the dataset's ID, name, and embed URL.
    public class EmbeddedDataset
    {
        // 'Id' stores the unique identifier of the dataset in Power BI.
        public string Id;

        // 'Name' holds the name of the dataset.
        public string Name;

        // 'EmbedUrl' stores the URL used to embed the dataset, allowing access to the dataset in embedded applications.
        public string EmbedUrl;
    }
}
