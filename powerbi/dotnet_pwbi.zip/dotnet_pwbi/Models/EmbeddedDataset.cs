namespace PowerBiEmbed.Models
{
	// Represents a Power BI dataset
	public class EmbeddedDataset
	{
		public string Id;
		public string Name;
		public string EmbedUrl;
	}
}