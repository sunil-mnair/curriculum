using Microsoft.Identity.Web;  // Provides integration for Microsoft identity (e.g., Azure AD authentication)
using PowerBiEmbed.Services;  // References the custom Power BI service for embedding functionality

namespace SalesReporting  // Declares the namespace for the startup class related to Sales Reporting
{
    // The Startup class is responsible for configuring the services and middleware for the application
    public class Startup
    {
        // Constructor that takes the application configuration (from appsettings.json or environment variables) and assigns it to the 'Configuration' property
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;  // Assigns the provided configuration to the property
        }

        // Public property to hold the application's configuration settings
        public IConfiguration Configuration { get; }

        // This method is called by the runtime to register services into the Dependency Injection (DI) container
        public void ConfigureServices(IServiceCollection services)
        {
            // Defines the required Power BI API scope for authentication
            string[] scopes = new string[] { PowerBiApiService.PowerBiDefaultScope };

            // Adds Microsoft Identity authentication using the configuration settings
            services.AddMicrosoftIdentityWebAppAuthentication(Configuration) 
                // Enables token acquisition for calling downstream APIs like Power BI
                .EnableTokenAcquisitionToCallDownstreamApi(scopes)
                // Caches tokens in memory to avoid redundant requests for tokens
                .AddInMemoryTokenCaches();

            // Registers the PowerBiApiService as a scoped service, meaning a new instance is created per request
            services.AddScoped(typeof(PowerBiApiService));
        }
    }
}
